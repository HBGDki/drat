library(testthat)
library(lazyrmd)

test_check("lazyrmd")
