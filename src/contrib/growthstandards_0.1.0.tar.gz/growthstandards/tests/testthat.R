library(testthat)
library(growthstandards)

test_check("growthstandards")
