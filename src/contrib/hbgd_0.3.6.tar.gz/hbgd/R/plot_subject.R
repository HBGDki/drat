# trajectory plots for a subject
# could be a grid plot with both height and weight
# could superpose other variables, etc.
NULL
