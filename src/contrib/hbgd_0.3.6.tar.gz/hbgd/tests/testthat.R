library(testthat)
library(hbgd)

test_check("hbgd")
